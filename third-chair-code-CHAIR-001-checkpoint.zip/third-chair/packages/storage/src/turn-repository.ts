import {
  ActorIntentSchema,
  CheckResolutionSchema,
  DecisionRequestSchema,
  ResolutionPlanSchema,
  TurnProposalSchema,
  WorldStateSchema,
} from "@third-chair/contracts";
import type { DatabaseSync } from "node:sqlite";
import type {
  BeginTurnInput,
  BeginTurnResult,
  CampaignId,
  ClientRequestId,
  CommitTurnInput,
  CommittedTurn,
  JsonValue,
  TurnFailure,
  TurnId,
  TurnRecord,
  TurnRepository,
  TurnStatus,
} from "./types.js";

interface TurnRow {
  id: string;
  campaign_id: string;
  branch_id: string;
  client_request_id: string;
  expected_state_version: number;
  decision_id: string;
  input_hash: string;
  status: TurnStatus;
  before_state_json: string;
  before_state_hash: string;
  locked_intents_json: string;
  model_profile_json: string | null;
  resolution_plan_json: string | null;
  resolutions_json: string | null;
  director_proposal_json: string | null;
  candidate_state_json: string | null;
  narration_json: string | null;
  next_decision_json: string | null;
  error_json: string | null;
  committed_state_version: number | null;
  created_at: string;
  updated_at: string;
}

interface CommitCampaignRow {
  id: string;
  state_version: number;
  current_state_json: string;
  current_state_hash: string;
  current_decision_json: string;
}

function stringifyJson(value: JsonValue): string {
  const json = JSON.stringify(value);
  if (json === undefined) throw new Error("INVALID_JSON_VALUE");
  JSON.parse(json);
  return json;
}

function parseJson(json: string): JsonValue {
  return JSON.parse(json) as JsonValue;
}

function parseFailure(json: string): TurnFailure {
  const value = JSON.parse(json) as Partial<TurnFailure>;
  if (typeof value.code !== "string" || typeof value.message !== "string") {
    throw new Error("INVALID_TURN_FAILURE");
  }
  return value as TurnFailure;
}

function parseTurn(row: TurnRow): TurnRecord {
  let resolutions: readonly import("@third-chair/contracts").CheckResolution[] | null = null;
  let nextRngCounter: number | null = null;
  if (row.resolutions_json !== null) {
    const stored = JSON.parse(row.resolutions_json) as {
      resolutions?: unknown;
      nextRngCounter?: unknown;
    };
    if (!Array.isArray(stored.resolutions) || !Number.isSafeInteger(stored.nextRngCounter)) {
      throw new Error("INVALID_STORED_RESOLUTIONS");
    }
    resolutions = CheckResolutionSchema.array().parse(stored.resolutions);
    nextRngCounter = stored.nextRngCounter as number;
  }
  return {
    id: row.id,
    campaignId: row.campaign_id,
    branchId: row.branch_id,
    clientRequestId: row.client_request_id,
    expectedStateVersion: row.expected_state_version,
    decisionId: row.decision_id,
    inputHash: row.input_hash,
    status: row.status,
    beforeState: WorldStateSchema.parse(JSON.parse(row.before_state_json)),
    beforeStateHash: row.before_state_hash,
    lockedIntents: ActorIntentSchema.array().parse(JSON.parse(row.locked_intents_json)),
    modelProfile: row.model_profile_json === null ? null : parseJson(row.model_profile_json),
    resolutionPlan: row.resolution_plan_json === null ? null : ResolutionPlanSchema.parse(JSON.parse(row.resolution_plan_json)),
    resolutions,
    nextRngCounter,
    directorProposal: row.director_proposal_json === null ? null : TurnProposalSchema.parse(JSON.parse(row.director_proposal_json)),
    candidateState: row.candidate_state_json === null
      ? null
      : WorldStateSchema.parse(JSON.parse(row.candidate_state_json)),
    narration: row.narration_json === null ? null : parseJson(row.narration_json),
    nextDecision: row.next_decision_json === null
      ? null
      : DecisionRequestSchema.parse(JSON.parse(row.next_decision_json)),
    failure: row.error_json === null ? null : parseFailure(row.error_json),
    committedStateVersion: row.committed_state_version,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

function transitionError(): Error {
  return new Error("ILLEGAL_TURN_TRANSITION");
}

class SqliteTurnRepository implements TurnRepository {
  constructor(private readonly db: DatabaseSync) {}

  beginTurn(input: BeginTurnInput): BeginTurnResult {
    const lockedIntents = ActorIntentSchema.array().parse(input.lockedIntents);
    const createdAt = input.createdAt ?? new Date().toISOString();
    this.db.exec("BEGIN IMMEDIATE");
    try {
      const existing = this.findByRequest(input.campaignId, input.clientRequestId);
      if (existing !== null) {
        if (existing.inputHash !== input.inputHash) {
          throw new Error("IDEMPOTENCY_KEY_REUSED_WITH_DIFFERENT_INPUT");
        }
        this.db.exec("COMMIT");
        return { kind: "EXISTING", turn: existing };
      }

      const active = this.db.prepare(`
        SELECT turns.* FROM active_turns
        JOIN turns ON turns.id = active_turns.turn_id
        WHERE active_turns.campaign_id = ?
      `).get(input.campaignId) as TurnRow | undefined;
      if (active) {
        const turn = parseTurn(active);
        this.db.exec("COMMIT");
        return { kind: "ACTIVE_SUCCESSOR", turn };
      }

      const campaign = this.db.prepare(`
        SELECT state_version, current_state_json, current_state_hash,
               current_decision_json, active_branch_id
        FROM campaigns WHERE id = ?
      `).get(input.campaignId) as {
        state_version: number;
        current_state_json: string;
        current_state_hash: string;
        current_decision_json: string;
        active_branch_id: string;
      } | undefined;
      if (!campaign) throw new Error("CAMPAIGN_NOT_FOUND");
      const beforeState = WorldStateSchema.parse(JSON.parse(campaign.current_state_json));
      const currentDecision = DecisionRequestSchema.parse(JSON.parse(campaign.current_decision_json));
      if (
        campaign.state_version !== input.expectedStateVersion
        || beforeState.metadata.stateVersion !== input.expectedStateVersion
      ) {
        throw new Error("STATE_VERSION_CONFLICT");
      }
      if (
        currentDecision.id !== input.decisionId
        || beforeState.currentDecision.id !== input.decisionId
      ) {
        throw new Error("DECISION_CONFLICT");
      }
      if (currentDecision.stateVersion !== input.expectedStateVersion) {
        throw new Error("DECISION_VERSION_CONFLICT");
      }
      if (campaign.active_branch_id !== input.branchId) throw new Error("ACTIVE_BRANCH_MISMATCH");
      const branch = this.db.prepare(
        "SELECT campaign_id, status FROM branches WHERE id = ?",
      ).get(input.branchId) as { campaign_id: string; status: string } | undefined;
      if (branch?.campaign_id !== input.campaignId || branch.status !== "ACTIVE") {
        throw new Error("BRANCH_OWNERSHIP_MISMATCH");
      }

      this.db.prepare(`
        INSERT INTO turns(
          id, campaign_id, branch_id, client_request_id, expected_state_version,
          decision_id, input_hash, status, before_state_json, before_state_hash,
          locked_intents_json, model_profile_json, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, 'PROCESSING', ?, ?, ?, ?, ?, ?)
      `).run(
        input.turnId,
        input.campaignId,
        input.branchId,
        input.clientRequestId,
        input.expectedStateVersion,
        input.decisionId,
        input.inputHash,
        JSON.stringify(beforeState),
        campaign.current_state_hash,
        JSON.stringify(lockedIntents),
        input.modelProfile === undefined ? null : stringifyJson(input.modelProfile),
        createdAt,
        createdAt,
      );
      this.db.prepare(`
        INSERT INTO active_turns(
          campaign_id, turn_id, reserved_state_version, reserved_decision_id, reserved_at
        ) VALUES (?, ?, ?, ?, ?)
      `).run(
        input.campaignId,
        input.turnId,
        input.expectedStateVersion,
        input.decisionId,
        createdAt,
      );
      const turn = this.getTurn(input.turnId);
      this.db.exec("COMMIT");
      return { kind: "STARTED", turn };
    } catch (error) {
      if (this.db.isTransaction) this.db.exec("ROLLBACK");
      throw error;
    }
  }

  persistPlan(turnId: TurnId, plan: import("@third-chair/contracts").ResolutionPlan): void {
    const result = this.db.prepare(`
      UPDATE turns SET resolution_plan_json = ?, status = 'PLANNED', updated_at = ?
      WHERE id = ? AND status = 'PROCESSING'
    `).run(stringifyJson(ResolutionPlanSchema.parse(plan) as unknown as JsonValue), new Date().toISOString(), turnId);
    if (Number(result.changes) !== 1) throw transitionError();
  }

  persistResolutions(
    turnId: TurnId,
    resolutions: readonly import("@third-chair/contracts").CheckResolution[],
    rngCounter: number,
  ): void {
    if (!Number.isSafeInteger(rngCounter) || rngCounter < 0) throw new Error("INVALID_RNG_COUNTER");
    const payload = stringifyJson({ resolutions: CheckResolutionSchema.array().parse(resolutions), nextRngCounter: rngCounter });
    const result = this.db.prepare(`
      UPDATE turns SET resolutions_json = ?, status = 'RESOLVED', updated_at = ?
      WHERE id = ? AND status = 'PLANNED'
    `).run(payload, new Date().toISOString(), turnId);
    if (Number(result.changes) !== 1) throw transitionError();
  }

  persistProposal(turnId: TurnId, proposal: import("@third-chair/contracts").TurnProposal, candidate: import("@third-chair/contracts").WorldState): void {
    const parsedCandidate = WorldStateSchema.parse(candidate);
    const result = this.db.prepare(`
      UPDATE turns
      SET director_proposal_json = ?, candidate_state_json = ?, updated_at = ?
      WHERE id = ? AND status = 'RESOLVED'
    `).run(
      stringifyJson(TurnProposalSchema.parse(proposal) as unknown as JsonValue),
      JSON.stringify(parsedCandidate),
      new Date().toISOString(),
      turnId,
    );
    if (Number(result.changes) !== 1) throw transitionError();
  }

  markAwaitingInput(turnId: TurnId, decision: import("@third-chair/contracts").DecisionRequest): void {
    const parsedDecision = DecisionRequestSchema.parse(decision);
    const result = this.db.prepare(`
      UPDATE turns SET status = 'AWAITING_INPUT', next_decision_json = ?, updated_at = ?
      WHERE id = ? AND status IN ('PROCESSING', 'RESOLVED')
    `).run(JSON.stringify(parsedDecision), new Date().toISOString(), turnId);
    if (Number(result.changes) !== 1) throw transitionError();
  }

  markFailed(turnId: TurnId, failure: TurnFailure): void {
    const result = this.db.prepare(`
      UPDATE turns SET status = 'FAILED', error_json = ?, updated_at = ?
      WHERE id = ? AND status <> 'COMMITTED'
    `).run(stringifyJson(failure as unknown as JsonValue), new Date().toISOString(), turnId);
    if (Number(result.changes) !== 1) throw transitionError();
  }

  abandonTurn(turnId: TurnId, failure: TurnFailure): void {
    const now = new Date().toISOString();
    this.db.exec("BEGIN IMMEDIATE");
    try {
      const result = this.db.prepare(`
        UPDATE turns SET status = 'FAILED', error_json = ?, updated_at = ?
        WHERE id = ? AND status <> 'COMMITTED'
      `).run(stringifyJson(failure as unknown as JsonValue), now, turnId);
      if (Number(result.changes) !== 1) throw transitionError();
      this.db.prepare("DELETE FROM active_turns WHERE turn_id = ?").run(turnId);
      this.db.exec("COMMIT");
    } catch (error) {
      if (this.db.isTransaction) this.db.exec("ROLLBACK");
      throw error;
    }
  }

  commitTurn(input: CommitTurnInput): CommittedTurn {
    const narrationJson = stringifyJson(input.narration);
    const nextDecision = DecisionRequestSchema.parse(input.nextDecision);
    const committedAt = input.committedAt ?? new Date().toISOString();
    if (input.candidateStateHash.length === 0) throw new Error("STATE_HASH_REQUIRED");

    this.db.exec("BEGIN IMMEDIATE");
    try {
      const turn = this.getTurn(input.turnId);
      if (turn.status !== "RESOLVED" && turn.status !== "AWAITING_INPUT") {
        throw transitionError();
      }
      if (turn.candidateState === null || turn.nextRngCounter === null) {
        throw new Error("TURN_NOT_FINALIZED");
      }
      const beforeState = WorldStateSchema.parse(turn.beforeState);
      const candidate = WorldStateSchema.parse(turn.candidateState);
      const campaign = this.db.prepare(`
        SELECT id, state_version, current_state_json, current_state_hash, current_decision_json
        FROM campaigns WHERE id = ?
      `).get(turn.campaignId) as CommitCampaignRow | undefined;
      if (!campaign) throw new Error("CAMPAIGN_NOT_FOUND");
      const currentState = WorldStateSchema.parse(JSON.parse(campaign.current_state_json));
      const currentDecision = DecisionRequestSchema.parse(JSON.parse(campaign.current_decision_json));

      if (turn.beforeStateHash !== campaign.current_state_hash) throw new Error("BEFORE_STATE_HASH_MISMATCH");
      if (
        campaign.state_version !== turn.expectedStateVersion
        || currentState.metadata.stateVersion !== turn.expectedStateVersion
        || beforeState.metadata.stateVersion !== turn.expectedStateVersion
      ) {
        throw new Error("STATE_VERSION_CONFLICT");
      }
      if (JSON.stringify(currentState) !== JSON.stringify(beforeState)) {
        throw new Error("BEFORE_STATE_MISMATCH");
      }
      if (currentDecision.id !== turn.decisionId || beforeState.currentDecision.id !== turn.decisionId) {
        throw new Error("DECISION_CONFLICT");
      }

      const reservation = this.db.prepare(`
        SELECT turn_id, reserved_state_version, reserved_decision_id
        FROM active_turns WHERE campaign_id = ?
      `).get(turn.campaignId) as {
        turn_id: string;
        reserved_state_version: number;
        reserved_decision_id: string;
      } | undefined;
      if (reservation?.turn_id !== turn.id) throw new Error("ACTIVE_RESERVATION_OWNER_MISMATCH");
      if (
        reservation.reserved_state_version !== turn.expectedStateVersion
        || reservation.reserved_decision_id !== turn.decisionId
      ) {
        throw new Error("ACTIVE_RESERVATION_MISMATCH");
      }
      const branch = this.db.prepare(
        "SELECT campaign_id FROM branches WHERE id = ?",
      ).get(turn.branchId) as { campaign_id: string } | undefined;
      if (branch?.campaign_id !== turn.campaignId) throw new Error("BRANCH_OWNERSHIP_MISMATCH");

      const committedVersion = campaign.state_version + 1;
      if (candidate.metadata.campaignId !== turn.campaignId) throw new Error("CANDIDATE_CAMPAIGN_MISMATCH");
      if (candidate.metadata.stateVersion !== committedVersion) throw new Error("CANDIDATE_VERSION_MISMATCH");
      if (candidate.metadata.turnNumber !== beforeState.metadata.turnNumber + 1) {
        throw new Error("TURN_NUMBER_MISMATCH");
      }
      if (candidate.metadata.rngCounter !== turn.nextRngCounter) throw new Error("RNG_COUNTER_MISMATCH");
      if (
        candidate.currentDecision.stateVersion !== committedVersion
        || nextDecision.stateVersion !== committedVersion
      ) {
        throw new Error("NEXT_DECISION_VERSION_MISMATCH");
      }
      if (JSON.stringify(candidate.currentDecision) !== JSON.stringify(nextDecision)) {
        throw new Error("NEXT_DECISION_MISMATCH");
      }

      const updatedCampaign = this.db.prepare(`
        UPDATE campaigns
        SET state_version = ?, current_state_json = ?, current_state_hash = ?,
            current_decision_json = ?, updated_at = ?
        WHERE id = ? AND state_version = ? AND current_state_hash = ?
      `).run(
        committedVersion,
        JSON.stringify(candidate),
        input.candidateStateHash,
        JSON.stringify(nextDecision),
        committedAt,
        turn.campaignId,
        turn.expectedStateVersion,
        turn.beforeStateHash,
      );
      if (Number(updatedCampaign.changes) !== 1) throw new Error("CAMPAIGN_COMPARE_AND_SET_FAILED");
      const updatedTurn = this.db.prepare(`
        UPDATE turns
        SET status = 'COMMITTED', narration_json = ?, next_decision_json = ?,
            committed_state_version = ?, updated_at = ?
        WHERE id = ? AND status IN ('RESOLVED', 'AWAITING_INPUT')
      `).run(narrationJson, JSON.stringify(nextDecision), committedVersion, committedAt, turn.id);
      if (Number(updatedTurn.changes) !== 1) throw transitionError();
      this.db.prepare(`
        INSERT INTO turn_events(turn_id, status, payload_hash, created_at)
        VALUES (?, 'COMMITTED', ?, ?)
      `).run(turn.id, input.candidateStateHash, committedAt);
      const released = this.db.prepare(
        "DELETE FROM active_turns WHERE campaign_id = ? AND turn_id = ?",
      ).run(turn.campaignId, turn.id);
      if (Number(released.changes) !== 1) throw new Error("ACTIVE_RESERVATION_RELEASE_FAILED");
      const committed = this.getTurn(turn.id);
      this.db.exec("COMMIT");
      return committed as CommittedTurn;
    } catch (error) {
      if (this.db.isTransaction) this.db.exec("ROLLBACK");
      throw error;
    }
  }

  getTurn(turnId: TurnId): TurnRecord {
    const row = this.db.prepare("SELECT * FROM turns WHERE id = ?").get(turnId) as
      | TurnRow
      | undefined;
    if (!row) throw new Error("TURN_NOT_FOUND");
    return parseTurn(row);
  }

  findByRequest(campaignId: CampaignId, clientRequestId: ClientRequestId): TurnRecord | null {
    const row = this.db.prepare(
      "SELECT * FROM turns WHERE campaign_id = ? AND client_request_id = ?",
    ).get(campaignId, clientRequestId) as TurnRow | undefined;
    return row ? parseTurn(row) : null;
  }
}

export function createTurnRepository(db: DatabaseSync): TurnRepository {
  return new SqliteTurnRepository(db);
}
